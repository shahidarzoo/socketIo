var express  = require('express');
var socket = require('socket.io');

//App setup
var app = express();
const hostname = '127.0.0.1';
const port = 5000;


var server = app.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});

//static path
app.use(express.static('public'));

//socket invoke
var io = socket(server);
io.on('connection', function(socket){
	console.log('client has connected to the server');

	// Handle Event Chat
	socket.on('chat', function(data){
		io.sockets.emit('chat', data);
	});

	socket.on('typing', function(data){
		socket.broadcast.emit('typing', data);
	});

});